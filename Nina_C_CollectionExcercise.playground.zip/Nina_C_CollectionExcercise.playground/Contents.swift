import UIKit

var collectionList: [String] = ["Spongebob" , "BuildABear"]


if collectionList.isEmpty {
    print("The teddy bear collection list is empty.")
} else {
    print("The teddy bear collection list is not empty.")
}

collectionList += ["Owl" , "Tiger"]
collectionList += ["Beanie Baby", "Care Bear", "Mushu", "Hamster", "Graduation bear"]

var firstItem = collectionList[0]

print("The teddy bear collection list contains \(collectionList.count) items.")

for item in collectionList{
    print(item)
}

let companyArray = ["Spongebob","BuildABear","Owl","Tiger","Beanie Baby", "Care Bear", "Mushu", "Hamster","Graduation bear"]
let sortedArray = companyArray.sorted(by: { $0 < $1 })
print(sortedArray)
